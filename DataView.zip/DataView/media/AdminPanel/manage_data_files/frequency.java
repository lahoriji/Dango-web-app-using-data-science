import java.lang.*;
import java.text.*;
import java.util.*;

 class Frequency{



	public static void frequency(){


		System.out.println("hello java");


		}

	public static void main(){



		 frequency();



		}





	}