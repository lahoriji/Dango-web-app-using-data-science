$(document).ready(function(){
		$(".close_View_container").click((e)=>{
			$("#View_container").removeClass("active_View_container");
		});
		$(".view_View_container").click((e)=>{
			e.preventDefault();
			$("#View_container").addClass("active_View_container");
 });
		$("body").delegate(".view_View_container","click",function(e){
			e.preventDefault();
			filedata =$(this).attr("FileData");

			$.ajax({

				url:"viewpage/",
				type:"POST",
				data:{
					filedata:filedata,
					csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
				},
				success:function(response){
					$("#show_view_data").html(response);
				}

			});



		});
});