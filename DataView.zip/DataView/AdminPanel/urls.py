from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('manage_data_visual/',views.manageData,name='manage_data_visual'),
    path('manage_data_visual/viewpage/',views.ViewData,name='ViewData'),
    path('Visualize/',views.Visualize,name='Visualize'),


]