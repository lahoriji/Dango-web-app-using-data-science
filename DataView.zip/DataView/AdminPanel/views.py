from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from django.contrib import messages 
import pandas as pd
# Create your views here.
def index(request):

	return render(request,'AdminPanel/index.html')



def manageData(request):
	if request.method=="POST" and request.FILES:
		filename = str(request.FILES['files_data']).split('.')
		exe = filename[-1:]
		if "csv" in exe:
			upload = Files.objects.create(filename=request.FILES['files_data'])
			upload.save()
			messages.info(request,"")
		else:
			messages.error(request,"Only CSV Format allowed!")


	all_files = Files.objects.all()
	return render(request,'AdminPanel/manaData.html',{"all_files":all_files})

def ViewData(request):
	if request.method=="POST":
		file_id = request.POST['filedata']
		obj = Files.objects.filter(id=file_id)
		for i in obj:
			df = pd.read_csv("media/"+str(i.filename))
			return HttpResponse(df.head(5).to_html())

	all_files = Files.objects.all()
	return render(request,'AdminPanel/manaData.html',{"all_files":all_files})

def Visualize(request):
	return render(request,'AdminPanel/Visualize.html')
