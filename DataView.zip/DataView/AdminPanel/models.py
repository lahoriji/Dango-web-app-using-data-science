from django.db import models

# Create your models here.
class Files(models.Model):
	filename = models.FileField(upload_to='AdminPanel/manage_data_files/',default='default')
	upload_date = models.DateTimeField(auto_now_add=True)


	
