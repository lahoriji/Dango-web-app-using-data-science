from django.shortcuts import render
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from django.http import HttpResponse
import io
# Create your views here.
def index(request):
	# if request.method=="POST":
	# 	x_val = str(request.POST['x']).split(',')
	# 	y_val = str(request.POST['y']).split(',')
		

	# 	fig = plt.figure()
	# 	plt.bar(x_val,y_val)
	# 	plt.figure(figsize=(3,4))
	# 	imgdata = io.StringIO()
	# 	fig.savefig(imgdata, format='svg')
	# 	fig = plt.gcf()
	# 	fig.set_size_inches(8, 6)
	# 	imgdata.seek(0)

	# 	data = imgdata.getvalue()
	# 	return HttpResponse(data)
	return render(request,'appone/index.html')



def pie(request):
	if request.method=="POST":
		x_val  = str(request.POST['x_val']).split(',')
		legend_name  = str(request.POST['legend_name']).split(',')
		color_name  = str(request.POST['color_name']).split(',')
		explode = str(request.POST['explode']).split(',')
		shadow  = str(request.POST['shadow'])
		autopct = str(request.POST['autopct'])
		l = []
		for i in explode:
			l.append(float(i))
		exp = tuple(l)
		fig = plt.figure()
		plt.pie(x_val,autopct=autopct,explode=exp,shadow=shadow,colors=color_name,labels=legend_name)
		plt.legend()
		plt.title('Pie Chart Figure')
		imgdata = io.StringIO()
		fig.savefig(imgdata, format='svg')
		imgdata.seek(0)
		data = imgdata.getvalue()
		return HttpResponse(data)
	return render(request,'appone/pie.html')


def line(request):
	if request.method=="POST":
		name = []
		value_y = []
		colors_y = []

		name = request.POST.getlist('arr_name[]')
		value_y = request.POST.getlist('arr_y_value[]')
		colors_y = request.POST.getlist('color_y[]')
		x_val_line = str(request.POST['x_vals']).split(',')
		titlex = request.POST['title_x']
		titley = request.POST['title_y']
		fig = plt.figure()
		print(x_val_line)
		for i in range(len(value_y)):
			l2 = str(value_y[i]).split(',')
			plt.plot(x_val_line,l2,label=name[i],color=colors_y[i])

		plt.legend()
		plt.title('Line Chart ')	
		plt.xlabel(titlex)
		plt.ylabel(titley)
		imgdata = io.StringIO()
		fig.savefig(imgdata,format='svg')
		imgdata.seek(0)
		data = imgdata.getvalue()
		return HttpResponse(data)

	return render(request,'appone/line.html')



def bar(request):
	if request.method=="POST":
		xtitle = str(request.POST['x_bar_title'])
		xvalues = str(request.POST['x_bar_values']).split(',')

		ytitle = str(request.POST['y_bar_title'])
		yvalues = str(request.POST['y_bar_values']).split(',')
		fig = plt.figure()
		
		plt.bar(xvalues,yvalues)

		plt.xlabel(xtitle)
		plt.ylabel(ytitle)
		# draw 
		
		imgdata = io.StringIO()
		fig.savefig(imgdata,format='svg')
		imgdata.seek(0)
		data = imgdata.getvalue()
		return HttpResponse(data)

		# print(xtitle,xvalues,ytitle,yvalues)


	return render(request,'appone/bar.html')