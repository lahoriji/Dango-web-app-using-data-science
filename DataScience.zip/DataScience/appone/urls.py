from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    path('',views.index,name='home'),
    path('pie',views.pie,name='pie'),
    path('line',views.line,name='line'),
    path('bar',views.bar,name='bar'),
]

