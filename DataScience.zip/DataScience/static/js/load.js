$(document).ready(function(){


		// $("#draw").click(function(){
		// 	var x = $("#x_val").val();
		// 	var y = $("#y_val").val();

		// 	if(x=='' || y==''){
		// 		alert('Please Fill Values');
		// 	}
		// 	else{


		// 	$.ajax({

		// 		url:"",
		// 		type:"POST",
		// 		data:{
		// 			x:x,
		// 			y:y,
		// 			csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
		// 		},
		// 		success:function(response){
		// 			//alert(response);
		// 			$("#show_chart").addClass('show_chart_pic');
		// 			$("#show_chart").html(response);
		// 		}

		// 	});
		// }

		// });


		$("#social_container_toggle").click(function(){
			$("#social_container").toggleClass("active_s_c");
		});

		$("#open_main_container").click(function(){
			$("#message_box").toggleClass('active_m_b');
		});

		$("#draw_pie").click(function(){
			var x_val = $("#value_pie").val();
			var legend_name = $("#legend_name").val();
			var color_name = $("#color_name").val();
			var explode= $("#explode").val();
			var shadow = $("#shadow").val();
			var autopct = $("#autopct").val();
			if (x_val=='' || legend_name=='' ||color_name==''||explode=='' ||shadow==''||autopct==''){
				alert("Please Fill Correctly!");
			}else{
			$.ajax({

				url:"",
				type:"POST",
				data:{
					x_val:x_val,
					legend_name:legend_name,
					color_name:color_name,
					explode:explode,
					shadow:shadow,
					autopct:autopct,
					csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
				},
				success:function(response){
					$("#show_pie").html(response);

				}







			});
}

			
		});

		$("#whole").mousemove(function(e){
			$("#show_pie").css("marginLeft",-e.pageX+$("#whole").offset().left);
			$("#show_pie").css("marginTop",-e.pageY+$("#whole").offset().top);

		});
		$("#whole").mouseout(function(e){
			$("#show_pie").css("marginLeft",0);
			$("#show_pie").css("marginTop",0);
		});
     var count=0;
		$("#select_id").change(function(e){
			 count = $(this).val();
			$("#display_y_fields").html('');
			for(i=0;i<count;i++){
				$("#display_y_fields").append("<table class='table'><tr><td><input type='text'  class='form-control' placeholder='Name' id='n"+count+i+"'></td><td><input  placeholder='Values'class='form-control' type='text' id='y"+count+i+"'></td><td><input type='text' class='form-control' placeholder='color' id='c"+count+i+"' ></td></tr></table>");
			}
		});	


		$("#draw_line").click(function(e){
			 var x_val_line=$("#x_value_line").val();
			 var title_x = $("#x_title_line").val();
			  var title_y = $("#y_title_line").val();
			 var arr_name = [];
			 var arr_y_value = [];
			 var color_y=[];
			  for(i=0;i<count;i++){
			  	arr_name[i] = $("#n"+count+i).val();
			  	arr_y_value[i] = $("#y"+count+i).val();
			  	color_y[i] = $("#c"+count+i).val();
			  }
			 $.ajax({

				url:"",
				type:"POST",
				data:{
					'arr_name[]':arr_name,
					'arr_y_value[]':arr_y_value,
					x_vals:x_val_line,
					'color_y[]':color_y,
					title_y:title_y,
					title_x:title_x,
					csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
				},
				success:function(response){
					$("#show_line").html(response);
				}







			});
		});



		$("#draw_bar").click(function(){
			var x_bar_title = $("#x_bar_title").val();
			var x_bar_values = $("#x_bar_values").val();
			var y_bar_title = $("#y_bar_title").val();
			var y_bar_values = $("#y_bar_values").val();

			$.ajax({

				url:"",
				type:"POST",
				data:{
					x_bar_title:x_bar_title,
					x_bar_values:x_bar_values,
					y_bar_title:y_bar_title,
					y_bar_values:y_bar_values,
					csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
				},
				success:function(response){
					$("#show_bar").html(response);
				}







			});

		});
});